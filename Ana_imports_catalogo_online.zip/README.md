# Ana_imports — catálogo online

## O que está pronto
- Página responsiva para celular e computador.
- Visual branco e preto.
- Busca e filtro por categoria.
- Botão de pedido que abre uma conversa no WhatsApp informado.
- Estrutura pronta para incluir fotos, descrições e preços.

## Como cadastrar produtos
1. Abra `products.js` em um editor de texto.
2. Dentro de `window.STORE_PRODUCTS`, adicione um bloco como este:
   {
     name: "Relógio digital",
     category: "Acessórios",
     description: "Relógio digital com pulseira ajustável",
     price: 45.90,
     image: "images/relogio.jpg"
   },
3. Salve a foto correspondente na pasta `images` e use exatamente o mesmo nome no campo `image`.
4. Separe os produtos por vírgula entre os blocos. O último bloco não leva vírgula.
5. O WhatsApp já está configurado como 55 + DDD + número. Confira antes de publicar.

## Como publicar gratuitamente usando GitHub Pages
1. Entre em https://github.com e crie uma conta ou acesse sua conta.
2. Crie um repositório público chamado `ana-imports-catalogo`.
3. Envie os arquivos `index.html`, `products.js`, `README.md` e a pasta `images` para o repositório.
4. No repositório, abra **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/(root)` e clique em **Save**.
7. Aguarde a publicação. O GitHub mostrará o endereço público nas configurações de Pages, normalmente no formato `https://SEU-USUARIO.github.io/ana-imports-catalogo/`.
8. Abra o link no celular para testar e compartilhe com os clientes.

O endereço acima é apenas um exemplo de formato; o link real só existe depois de publicar no GitHub Pages.

## Atualizar depois
Para adicionar ou alterar produtos, edite `products.js`, envie as novas fotos para `images` e faça commit das alterações no GitHub. A página será atualizada após a publicação.
