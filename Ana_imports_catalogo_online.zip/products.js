// CATÁLOGO ANA_IMPORTS
// Para cadastrar um produto, copie um bloco e preencha os campos.
// Coloque as fotos na pasta "images" e informe o caminho, por exemplo: "images/relogio.jpg".
// Preço deve ser número, por exemplo: 45.90. Para mostrar "Consulte", use price: null.

window.STORE_CONFIG = {
  whatsapp: "5527998730852" // Brasil + DDD + número, sem espaços ou símbolos
};

window.STORE_PRODUCTS = [
  // Exemplo de produto:
  // {
  //   name: "Nome do produto",
  //   category: "Acessórios",
  //   description: "Descrição curta do produto",
  //   price: 45.90,
  //   image: "images/nome-da-foto.jpg"
  // }
];
